package com.mygdx.game;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.graphics.g2d.Batch;

public class Pipe extends Actor {
    private final Rectangle bounds;
    private boolean upsideDown;
    private AssetManager manager;
    private Player player;

    public Pipe() {
        setSize(64, 230);
        bounds = new Rectangle();
        setVisible(false);
    }

    @Override
    public void act(float delta) {
        moveBy(-200 * delta, 0);
        bounds.set(getX(), getY(), getWidth(), getHeight());


        if (player != null && bounds.overlaps(player.getBounds())) {
            player.notificarColision();
        }

        if (!isVisible()) {
            setVisible(true);
        }

        if (getX() < -64) {
            remove();
            dispose();
        }
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
        Texture pipeTexture = upsideDown ? manager.get("pipe_up.png", Texture.class) : manager.get("pipe_down.png", Texture.class);
        batch.draw(pipeTexture, getX(), getY());
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public boolean isUpsideDown() {
        return upsideDown;
    }

    public void setUpsideDown(boolean upsideDown) {
        this.upsideDown = upsideDown;
    }

    public void setManager(AssetManager manager) {
        this.manager = manager;
    }

    public void dispose() {
        // Agrega lógica de limpieza, si es necesario
    }
}