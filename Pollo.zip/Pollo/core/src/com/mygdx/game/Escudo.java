package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.graphics.g2d.Batch;

public class Escudo extends Actor {
    private final Rectangle bounds;
    private AssetManager manager;

    public void setPlayer(Player player) {
        this.player = player;
    }

    private Player player;

    public Escudo(float x, float y) {
        setSize(20, 20); // Tamaño del objeto especial (escudo)
        setPosition(x, y);
        bounds = new Rectangle();
    }
    @Override
    public void act(float delta) {
        moveBy(-200 * delta, 0);
        bounds.set(getX(), getY(), getWidth(), getHeight());


        if (player != null && bounds.overlaps(player.getBounds())) {
            player.activarInmunidad(10);
        }

        if (!isVisible()) {
            setVisible(true);
        }

        if (getX() < -64) {
            remove();
            dispose();
        }
    }
    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
        float escudoWidth = 64f; // Ancho original del escudo
        float escudoHeight = 45f; // Altura original del escudo

        batch.draw(manager.get("escudo.png", Texture.class), getX(), getY(), escudoWidth, escudoHeight);
    }

    public Rectangle getBounds() {
        return bounds.set(getX(), getY(), getWidth(), getHeight());
    }

    public void setManager(AssetManager manager) {
        this.manager = manager;
    }

    public void dispose() {
        // Agrega lógica de limpieza, si es necesario
    }
}