package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

import java.util.Iterator;

public class GameScreen implements Screen {
    private Array<Pipe> obstacles;
    private long lastObstacleTime;
    private final Bird game;
    private boolean dead;
    private OrthographicCamera camera;
    private Stage stage;
    private Player player;
    private float score;
    private Escudo escudo;
    private static final int INTERVALO_APARICION_ESCUDO = 10;
    private int contadorEscudo = 0;

    public GameScreen(final Bird gam) {
        this.game = gam;
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
        player = new Player();
        player.setManager(game.manager);
        stage = new Stage();
        stage.getViewport().setCamera(camera);
        stage.addActor(player);

        obstacles = new Array<>();
        spawnObstacle();

        escudo = new Escudo(400, 240); // Posición inicial del escudo
        escudo.setManager(game.manager);
        stage.addActor(escudo);

        score = 0;
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0.3f, 0.8f, 0.8f, 1);


        // Draw======================================================
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();

        game.batch.draw(game.manager.get("background.png", Texture.class), 0, 0);
        escudo.draw(game.batch, delta);

        for (Pipe pipe : obstacles) {
            pipe.draw(game.batch, delta);
        }

        game.batch.end();

        stage.getBatch().setProjectionMatrix(camera.combined);
        stage.draw();

        game.batch.begin();
        game.smallFont.draw(game.batch, "Score: " + (int) score, 10, 470);
        game.bigFont.draw(game.batch, "Vidas: " + player.getVidas(), 450, 470);
        game.batch.end();

        // Update logica===========================================================
        if (Gdx.input.justTouched()) {
            player.impulso();
            game.manager.get("flap.wav", Sound.class).play();
        }

        stage.act();


        score += Gdx.graphics.getDeltaTime();



        // Comprova si cal generar un obstacle nou
        if (TimeUtils.nanoTime() - lastObstacleTime > 1500000000)
            spawnObstacle();

        checkCollisions();

        if (player.getVidas() == 0 || player.getBounds().y > 480 - player.getHeight()) {
            handleGameOver();
        }


    }

    private void spawnObstacle() {
        float holey = MathUtils.random(50, 230);

        Pipe pipe1 = new Pipe();
        pipe1.setX(800);
        pipe1.setY(holey - 230);
        pipe1.setUpsideDown(true);
        pipe1.setManager(game.manager);
        obstacles.add(pipe1);
        stage.addActor(pipe1);

        Pipe pipe2 = new Pipe();
        pipe2.setX(800);
        pipe2.setY(holey + 200);
        pipe2.setUpsideDown(false);
        pipe2.setManager(game.manager);
        obstacles.add(pipe2);
        stage.addActor(pipe2);

        contadorEscudo++;

        if (contadorEscudo >= 10) {
            escudo = new Escudo(800, holey);
            escudo.setManager(game.manager);
            escudo.setPlayer(player);
            stage.addActor(escudo);
            contadorEscudo = 0;
        }

        lastObstacleTime = TimeUtils.nanoTime();
    }

    /*private void spawnShield() {
        float pipeGap = 200;
        float minY = 50;
        float maxY = 430;
        float shieldY = MathUtils.random(minY, maxY);

        escudo.setX(800);
        escudo.setY(shieldY);

        escudo.setVisible(true);
        stage.addActor(escudo);
    }*/

    private void checkCollisions() {
        Iterator<Pipe> iter = obstacles.iterator();
        while (iter.hasNext()) {
            Pipe pipe = iter.next();
            if (pipe.getBounds().overlaps(player.getBounds())) {
                player.notificarColision();
            }
        }

        if (escudo.isVisible() && escudo.getBounds().overlaps(player.getBounds())) {
            player.activarInmunidad(10);
            escudo.setVisible(false);
        }
    }

    private void handleGameOver() {
        game.lastScore = (int) score;
        if (game.lastScore > game.topScore) {
            game.topScore = game.lastScore;
        }
        game.setScreen(new GameOverScreen(game));
        game.manager.get("fail.wav", Sound.class).play();
        dispose();
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {
    }
}
