package com.mygdx.game;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class Player extends Actor {
    private final Rectangle bounds;
    private float speedy, gravity;

    private TextureRegion normalBirdTexture;
    private TextureRegion immuneBirdTexture;
    private AssetManager manager;

    private int vidas = 3;
    private boolean inmune = false;
    private boolean conEscudo = false;
    private float tiempoRestanteInmunidad = 0f;
    private boolean dead;

    private static final float BIRD_WIDTH = 64f;
    private static final float BIRD_HEIGHT = 45f;
    private static final float GRAVITY = 850f;
    private static final float INMUNITY_TIME = 2f;

    Bird game;

    public Player() {
        setX(200);
        setY(280 / 2 - BIRD_HEIGHT / 2);
        setSize(BIRD_WIDTH, BIRD_HEIGHT);
        bounds = new Rectangle();
        speedy = 0;
        gravity = GRAVITY;
        tiempoRestanteInmunidad = INMUNITY_TIME;
    }

    @Override
    public void act(float delta) {
        moveBy(0, speedy * delta);
        speedy -= gravity * delta;

        if (inmune) {
            tiempoRestanteInmunidad -= delta;
            if (tiempoRestanteInmunidad <= 0) {
                inmune = false;
                tiempoRestanteInmunidad = 0f;

            }
        }

        bounds.set(getX(), getY(), getWidth(), getHeight());

        if (getY() > 480 - getHeight()) {
            setY(480 - getHeight());
        } else if (getY() < 0) {
            setY(0);
            dead = true;
        }
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
        Texture currentTexture = isInmune() ?  manager.get("inmune.png", Texture.class) : manager.get("bird.png", Texture.class);

        batch.draw(currentTexture, getX(), getY());
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void setManager(AssetManager manager) {
        this.manager = manager;
    }

    public void impulso() {
        speedy = 400f;
    }

    // Método para activar la apariencia con escudo
    public void activarAparienciaConEscudo() {
        conEscudo = true;
    }

    public int getVidas() {
        return vidas;
    }

    public void perderVida() {
        if (!inmune) {
            vidas--;

            if (vidas > 0) {
                // Activate immunity and reset position, etc. if you want
                activarInmunidad(3);
                // Reset player position or handle other logic as needed
            }
        }
    }
    public boolean isInmune() {
        return inmune;
    }

    // Método para notificar colisión desde Pipe
    public void notificarColision() {
        if (!isInmune()) {
            perderVida();
        }
    }

    // Método para activar la inmunidad durante un tiempo específico
    public void activarInmunidad(float time) {
        inmune = true;
        tiempoRestanteInmunidad = time;
    }
}